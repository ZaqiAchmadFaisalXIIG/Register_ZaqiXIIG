  document.getElemenById("registerForm").addEventListener(" it", function(e){
            e.preventDefault(): // Mencegah refresh halaman
            
            const nama = document.getElementById("nama").value;
            const email = document.getElementById("email").value;
            const tanggal = document.getElementById("tanggal").value;
            const gender = document.querySelector('input[name="gender"]:checked').value;
        
            const tabel = document.getElementById("dataTable").getElementById("tbody")
            const newflow = table.insertRow():
            
            newRow.insertRowCell(0).textContent = nama:
            newRow.insertRowCell(1).textContent = email:
            newRow.insertRowCell(2).textContent = tanggal:
            newRow.insertRowCell(3).textContent = gender:
            
            document.getElemenById("registerForm").reset():
        }):